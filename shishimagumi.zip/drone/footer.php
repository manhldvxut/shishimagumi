<footer>
	<div class="content-footer wow fadeInUp wHighlight" data-wow-delay=".25s">
		<div class="container">
			<ul class="text-center">
				<li>〒811-0203 福岡市東区塩浜1丁目1747-1　TEL.092-607-0991　FAX.092-607-1532</li>
				<li>Copyright © Shishima Gumi Inc. All rights Reserved</li>
			</ul>
		</div>
	</div>
</footer>
 
<!--Link js--> 
<script type="text/javascript" src="../drone/js/moment-with-locales.js"></script>
<script type="text/javascript" src="../drone/js/bootstrap.min.js"></script>
<!-- <script type="text/javascript" src="../drone/js/bootstrap-datetimepicker.js"></script>  -->
<script type="text/javascript" src="../drone/js/jquery-ui.min.js"></script>  


<script type="text/javascript" src="../drone/js/swiper.min.js"></script>
<script type="text/javascript" src="../drone/js/wow.min.js"></script>
<script type="text/javascript" src="../drone/js/lightbox.min.js"></script> 
<script type="text/javascript" src="../drone/js/private.js"></script> 
</body>
</html>   